
__author__ = "Andy Dustman <farcepest@gmail.com>"
version_info = (1,2,5,'final',1)
__version__ = "1.2.5"
